<?php $__env->startSection('cabecalho'); ?>
    Cadastro de Alunos para Estágios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
        <form name="form1" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <br/>
                Nome:<br/>
                <input class="form-control " id="input1" placeholder="Nome completo"
                       type="text" name="nome" tabindex="1" required autofocus maxlength="250"/>
            </div>
            <div class="row">
                <div class="col">
                    Matricula: <br/>
                    <input class="form-control" id="input2" placeholder="somente números"
                           type="text" name="id" tabindex="2"
                           onkeypress="return isNumberKey(event)" maxlength="16" required/>
                </div>
                <div class="col"></div>
            </div>
            <div class="row">
                <div class="col">
                    CPF: <br/>
                    <input class="form-control" id="inputcpf" placeholder="somente números" type="text" name="cpf"
                           tabindex="3" onkeypress="return isNumberKey(event)" maxlength="11" OnBlur="ValidaCPF()" required/>
                </div>
                <div class=" col">
                    RG: <br/>
                    <input class="form-control" id="input4" tabindex="4" placeholder="somente números"
                           type="text" name="rg" onkeypress="return isNumberKey(event)"
                           required maxlength="16"/>
                </div>


                <div class="col">
                    Data de Nascimento:<br/>
                    <input class="form-control col-md-8" id="inputdata" type="date" min="1800-12-31" max="2999-12-31"  name="data_nascimento" tabindex="5" OnBlur="ValidaDATA()"
                            required/>
                </div>
                <div class="col">
                    Sexo:
                    <select class="form-control col-md-8" name="sexo" id="input6" tabindex="6">
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        required
                    </select>
                </div>
            </div>
            <br/>
            <div>
                <h4>Contatos:</h4>
            </div>
            <div>
                Celular: <br/>
                <input class="form-control col-md-6" id="inputcel"
                       placeholder="Celular - somente números" type="text" name="celular"
                       tabindex="7"  onkeypress="return isNumberKey(event)"   maxlength="11" OnBlur="ValidaCEL()" />
            </div>
            <div>
                E-mail:<br/>
                <input class="form-control col-md-6" id="input8" placeholder="e-mail" type="text" tabindex="8"
                       name="email" maxlength="64"/>
            </div>
            <br/><br/>
            <div class="form-inline my-2 my-lg-0 justify-content-sm-around">
                <button class="btn btn-outline-primary">Adicionar</button>
                <a href="<?php echo e(url("/alunos")); ?>" class="btn btn-outline-danger">voltar</a>
                <a href="<?php echo e(url("/")); ?>" class="btn btn-outline-dark">Home</a>
            </div>
            <br/>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/alunos/create.blade.php ENDPATH**/ ?>