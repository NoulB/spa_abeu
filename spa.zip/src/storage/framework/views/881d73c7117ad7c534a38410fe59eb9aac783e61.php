<?php $__env->startSection('cabecalho'); ?>
    Editar Supervisor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(url("/supervisores/update/")); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <br/>
                Nome:<br/>
                <input class="form-control" id="input1" placeholder="Nome completo"
                       value="<?php echo e($supervisor->nome); ?>" type="text" name="nome" tabindex="1" required autofocus/>
            </div>
            <div class="row">
                <div class="col">
                    Matricula: <br/>
                    <input class="form-control" readonly id="input2" placeholder="somente números" type="text" name="id"
                           value="<?php echo e($supervisor->id); ?>" tabindex="2" onkeypress="return isNumberKey(event)" required/>
                </div>
                <div class="col">
                    CRP: <br/>
                    <input class="form-control" readonly id="input3" placeholder="Ex: 12345/5"
                           value="<?php echo e($supervisor->crp); ?>" type="text" name="crp" tabindex="3"/>
                </div>
            </div>

            <br>
            <div>
                <h4>Contatos:</h4>
            </div>
            <div>
                Celular: <br/>
                <input class="form-control col-md-6" id="input4"
                       placeholder="Celular - somente números" type="text" name="celular"
                       value="<?php echo e($supervisor->celular); ?>" tabindex="4" onkeypress="return isNumberKey(event)"/>
            </div>
            <div>
                E-mail:<br/>
                <input class="form-control col-md-6" id="input5"
                       placeholder="Celular - somente números" type="text" name="email"
                       value="<?php echo e($supervisor->email); ?>" tabindex="5"/>
            </div>
            <br/><br/>
            <div class="form-inline my-2 my-lg-0 justify-content-sm-around">
                <button class="btn btn-outline-primary">Salvar</button>
                <a href="<?php echo e(url("/supervisores")); ?>" class="btn btn-outline-danger">voltar</a>
                <a href="<?php echo e(url("/")); ?>" class="btn btn-outline-dark">Home</a>
            </div>
            <br/>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/supervisores/editar.blade.php ENDPATH**/ ?>