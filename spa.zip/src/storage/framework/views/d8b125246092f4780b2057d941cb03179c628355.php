<?php $__env->startSection('cabecalho'); ?>
    Supervisores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="col-sm-12">
        <?php if(!empty($mensagem)): ?>
            <div class="alert alert-success">
                <?php echo e($mensagem); ?>

            </div>
        <?php endif; ?>
        <br/>
        <form class="form-inline my-2 my-lg-0 justify-content-between mb-" action="<?php echo e(url('/supervisores/busca')); ?>"
              method="post">
            <div>
                <input class="form-control mr-sm-2" type="search" name="criterio" placeholder="Pesquisar...">
                <button class="btn btn-outline-primary  my-2 my-sm-0" type="submit"><i class="fas fa-search"></i>
                </button>
            </div>

            <a href="/supervisores/criar" class="btn btn-outline-success ">Adicionar</a>
            <?php echo e(csrf_field()); ?>


        </form>

        <div>
            <table class="table table-striped table-md table-borderless">
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>E-mail</th>
                    <th>CRP</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>
                            <a href="<?php echo e(url("/supervisores/show/$supervisor->id")); ?>">
                                <?php echo e($supervisor->nome); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url("/supervisores/show/$supervisor->id")); ?>">
                                <?php echo e($supervisor->celular); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url("/supervisores/show/$supervisor->id")); ?>" cllink="black">
                                <?php echo e($supervisor->email); ?>

                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url("/supervisores/show/$supervisor->id")); ?>" cllink="black">
                                <?php echo e($supervisor->crp); ?>

                            </a>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form class="navbar-form">
            <div class=text-right>
                <a href="/" class="btn btn-outline-danger mb-2">voltar</a>

            </div>
        </form>
    </div>
    <div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/supervisores/index.blade.php ENDPATH**/ ?>