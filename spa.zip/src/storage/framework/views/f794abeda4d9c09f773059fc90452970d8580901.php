<?php $__env->startSection('cabecalho'); ?>
Editar Paciente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

<div>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


    <form action="<?php echo e(url("/pacientes/update/")); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="id" value="<?php echo e($paciente->id); ?>">


        <div>
        <br/>
        Nome:<br/>
        <input class="form-control col-md-6" id="input1" placeholder="Nome completo"
               type="text" name="nome" value="<?php echo e($paciente->nome); ?>" size="50" tabindex="1" required autofocus/>

    </div>
    <div class="row">
        <div class="col">
            CPF: <br/>
            <input class="form-control" id="input2" placeholder="somente números" type="text" name="cpf"
                   value="<?php echo e($paciente->cpf); ?>" tabindex="2" onkeypress="return isNumberKey(event)" required/>
        </div>
        <div class="col">
            RG: <br/>
            <input class="form-control" id="input3" placeholder="somente números" type="text"
            name="rg" value="<?php echo e($paciente->rg); ?>" tabindex="3" onkeypress="return isNumberKey(event)" required/>
        </div>
        <div class="col">
            Data de Nascimento:<br/>
            <input class="form-control col-md-6" id="input4" type="date" name="data_nascimento"
                   value="<?php echo e($paciente->data_nascimento); ?>" tabindex="4" required/>
        </div>
    </div>
    <div>
        <div class="row">

            <div class="col">
                E-mail: <br/>
                <input class="form-control" id="input5" placeholder="E-mail" type="text" name="email"
                       value="<?php echo e($paciente->email); ?>" tabindex="6"/>
            </div>
            <div class="col">
                Celular: <br/>
                <input class="form-control col-md-6" id="input6" placeholder="Somente números"
                       type="text" name="celular" value="<?php echo e($paciente->celular); ?>"

                       size="20" tabindex="7" onkeypress="return isNumberKey(event)"/>
            </div>
            <div class="col">
                Telefone:<br/>
                <input class="form-control col-md-6" id="input7" placeholder="Telefone" type="text"
                       name="telefone" value="<?php echo e($paciente->telefone); ?>"
                       size="20" tabindex="8"
                       onkeypress="return isNumberKey(event)"/>
            </div>
        </div>
    </div>
    <div>
        <div class="row">
            <div class="col">
                Nome do Pai:<br/>
                <input class="form-control" id="input8" placeholder="Nome do Pai" type="text" name="pai"
                       value="<?php echo e($paciente->pai); ?>"
                       tabindex="9"/>
            </div>
            <div class="col">
                Nome do Mae:<br/>
                <input class="form-control" id="input9" placeholder="Nome da Mãe" type="text" name="mae"
                       value="<?php echo e($paciente->mae); ?>"
                       required
                       tabindex="10"/>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div class="row">
                <div class="col">
                    Sexo:
                    <select class="form-control col-md-6" name="sexo" value="<?php echo e($paciente->sexo); ?>" id="input10" tabindex="10">
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        required
                    </select>
                </div>
                <div class="col">
                    Estado civil:
                    <select class="form-control col-md-6" id="input11" name="estado_civil"
                            value="<?php echo e($paciente->estado_civil); ?>"
                            onchange="verifica(this.value)">
                        <option value="Casado">Casado(a)</option>
                        <option value="Solteiro" selected>Solteiro(a)</option>
                        <option value="Divorciado">Divorciado(a)</option>
                        <option value="Viúvo">Viúvo(a)</option>
                        required
                    </select>
                </div>
            </div>
        </div>
        <div class="col">
            Cônjuge:
            <input class="form-control" id="input12" placeholder="Nome do(a) Cônjuge"
                   type="text" id="input12" name="conjuge" value="<?php echo e($paciente->conjuge); ?>"/>
        </div>
    </div>
    <div>

    </div>
    <br/>
    <h4>Endereço:</h4>
    <div class="row">
        <div class="col">
            Logradouro:<br/>
            <input class="form-control" id="input13" placeholder="Logradouro" type="text" name="logradouro"
                   value="<?php echo e($paciente->logradouro); ?>"
                   size="37" required tabindex="14"/>
        </div>
        <div class="col">
            <div class="row">
                <div class="col">
                    Número:<br/>
                    <input class="form-control col-md-6" id="input14" placeholder="Numero" type="text"
                           name="numero" value="<?php echo e($paciente->numero); ?>"
                           size="10" required tabindex="15"
                           onkeypress="return isNumberKey(event)"/>
                </div>
                <div class="col">
                    Complemento:
                    <input class="form-control" id="input15" placeholder="Complemento" type="text"
                           name="complemento" value="<?php echo e($paciente->complemento); ?>"
                           size="20" tabindex="16"/>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <div class="row">
                <div class="col">
                    Bairro: <br/>
                    <input class="form-control" id="input16" placeholder="Bairro" type="text" name="bairro"
                           value="<?php echo e($paciente->bairro); ?>" size="27" required tabindex="17"/>
                </div>
                <div class="col">
                    Cidade: <br/>
                    <input class="form-control" id="input17" placeholder="Cidade" type="text" name="cidade"
                           value="<?php echo e($paciente->cidade); ?>" size="27" required tabindex="18"/>
                </div>
            </div>
        </div>
        <div class="col">
            CEP: <br/>
            <input class="form-control col-md-6" id="input18" placeholder="CEP" type="text" name="cep"
                   value="<?php echo e($paciente->cep); ?>"
                   size="20" required tabindex="19" onkeypress="return isNumberKey(event)"/>
        </div>
    </div>
    <br/><br/>
    <div class="form-inline my-2 my-lg-0 justify-content-sm-around">
        <button class="btn btn-outline-primary">Salvar</button>
        <a href="<?php echo e(route('listar_pacientes')); ?>" class="btn btn-outline-danger">Voltar</a>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-dark">Home</a>
    </div>
    <br/>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/pacientes/editar.blade.php ENDPATH**/ ?>