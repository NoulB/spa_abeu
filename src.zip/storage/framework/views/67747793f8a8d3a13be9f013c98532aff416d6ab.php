<?php $__env->startSection('cabecalho'); ?>
    Cadastro de Alunos para Estágios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <div >

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

        <form method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <input placeholder="Matrícula" type="text" name="matricula" tabindex="1" required
                       onkeypress="return isNumberKey(event)" autofocus>
            </fieldset>
            <fieldset>
                <input placeholder="Nome completo" type="text" name="nome" tabindex="2" required>
            </fieldset>

            <fieldset>
                <input placeholder="CPF (Somente Números)" type="text" name="cpf" tabindex="3"
                       onkeypress="return isNumberKey(event)" required>
            </fieldset>
            <fieldset>
                <input placeholder="RG (Somente Números)" type="text" name="rg" tabindex="4"
                       onkeypress="return isNumberKey(event)" required>
            </fieldset>
            <fieldset>
                <input placeholder="Email" type="email" name="email" tabindex="5" >
            </fieldset>
            <fieldset>
                <input placeholder="Celular (Somente Números)" type="tel" name="celular" tabindex="6"
                       onkeypress="return isNumberKey(event)" required >
            </fieldset>
            Data de nascimento:
            <fieldset>
                <input placeholder="Data nascimento" type="date" name="data_nascimento" tabindex="7" required>
            </fieldset>
            <fieldset>
                Sexo:
                <select name="sexo">
                    <option value="m">Masculino</option>
                    <option value="f">Feminino</option>

                </select>
            </fieldset>
            </br></br>



            <div class="form-inline my-2 my-lg-0 justify-content-sm-around">
                <button class="btn btn-primary">Adicionar</button>
                <a href="<?php echo e(url("/alunos")); ?>" class="btn btn-danger">voltar</a>
                <a href="<?php echo e(url("/")); ?>" class="btn btn-dark">Home</a>
            </div>

        </form>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/alunos/create.blade.php ENDPATH**/ ?>