<?php $__env->startSection('cabecalho'); ?>
    Alunos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="col-sm-12">
        <?php if(!empty($mensagem)): ?>
            <div class="alert alert-success">
                <?php echo e($mensagem); ?>

            </div>
        <?php endif; ?>

        <form class="form-inline my-2 my-lg-0 justify-content-between" action="<?php echo e(url('/alunos/busca')); ?>"
              method="post">
            <a href="/alunos/criar" class="btn btn-primary mb-2">Cadastrar Aluno</a>
            <?php echo e(csrf_field()); ?>

            <div>
                <input class="form-control mr-sm-2" type="search" name="criterio" placeholder="Pesquisar Aluno...">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i>
                </button>
            </div>
        </form>


        <div class="card-columns" id="alinha">
            <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item" style="background-color: #e3f2fd;">
                    <?php echo e($aluno->nome); ?>

                    <a href="<?php echo e(url("/supervisores/excluir/$aluno->id")); ?>"
                       class="btn btn-xs btn-danger btn-action">
                        <i class="fas fa-trash-alt"></i>
                    </a>
                    <a href="<?php echo e(url("/alunos/editar/$aluno->id")); ?>" class="btn btn-xs btn-primary btn-action">
                        <i class="fas fa-pencil-alt" float="right"></i>
                    </a>
                </li>
                <li class="list-group-item">
                    Celular: <?php echo e($aluno->celular); ?>

                </li></br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <div>
                <a href="/" class="btn btn-danger mb-2">voltar</a>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/alunos/index.blade.php ENDPATH**/ ?>