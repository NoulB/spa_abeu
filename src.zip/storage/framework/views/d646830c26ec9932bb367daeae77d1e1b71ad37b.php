<?php $__env->startSection('cabecalho'); ?>
    Cadastro de Supervisores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <input placeholder="Nome Completo" type="text" name="nome" size ="50"  tabindex="1" required autofocus/>
            </fieldset>
            <br>
            <fieldset>
                <input placeholder="Matrícula" type="text" name="matricula" size="20" tabindex="2" onkeypress="return isNumberKey(event)"/> &nbsp;&nbsp;&nbsp;
                <input placeholder="CRP" type="text" name="crp" size ="20" tabindex="3" required/>
            </fieldset>
            <br>

            <fieldset>
                Contatos: <br>
                <input placeholder="Celular" type="text" name="celular" size ="20" tabindex="6"
                       onkeypress="return isNumberKey(event)" required/>
                <br>
                <br>
                <input placeholder="E-mail" type="text" name="email" size="50" tabindex="7" required/><br/>

            </fieldset>
            <fieldset>

                </select>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </fieldset>
    <br/>
            <div class="form-inline my-2 my-lg-0 justify-content-sm-around">
                <button class="btn btn-primary">Adicionar</button>
                <a href="<?php echo e(url("/supervisores")); ?>" class="btn btn-danger">voltar</a>
                <a href="<?php echo e(url("/")); ?>" class="btn btn-dark">Home</a>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/supervisores/create.blade.php ENDPATH**/ ?>