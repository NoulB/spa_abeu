<?php $__env->startSection('cabecalho'); ?>
    Supervisores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="col-sm-12" >

        <?php if(!empty($mensagem)): ?>
            <div class="alert alert-success">
                <?php echo e($mensagem); ?>

            </div>
        <?php endif; ?>


        <form class="form-inline my-2 my-lg-0 justify-content-between" action="<?php echo e(url('/supervisores/busca')); ?>"
              method="post">
            <a href="/supervisores/criar" class="btn btn-primary mb-2">Cadastrar Supervisor</a>
            <?php echo e(csrf_field()); ?>




            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
            </nav>



            <div>
                <input class="form-control mr-sm-2" type="search" name="criterio" placeholder="Pesquisar Supervisor...">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i>
                </button>
            </div>
        </form>


        <div class="card-columns" id="alinha">
            <?php $__currentLoopData = $supervisores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <li class="list-group-item" style="background-color: #e3f2fd;">
                        <?php echo e($supervisor->nome); ?>

                        <a href="<?php echo e(url("/supervisores/excluir/$supervisor->id")); ?>"
                           class="btn btn-xs btn-danger btn-action">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                        <a href="<?php echo e(url("/supervisores/editar/$supervisor->id")); ?>"
                           class="btn btn-xs btn-primary btn-action">
                            <i class="fas fa-pencil-alt" float="right"></i>
                        </a>
                    </li>
                    <li class="list-group-item">
                        Celular: <?php echo e($supervisor->celular); ?>

                    </li>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <div>
                <a href="/" class="btn btn-danger mb-2">voltar</a>
            </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/supervisores/index.blade.php ENDPATH**/ ?>