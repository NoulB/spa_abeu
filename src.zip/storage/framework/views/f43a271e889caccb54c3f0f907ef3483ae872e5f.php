<?php $__env->startSection('cabecalho'); ?>
    SPA Uniabeu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="mr-sm-2">

        <div>
            <a href="/pacientes" class="btn btn-primary mb-2">Pacientes</a>
        </div>
        <div>
            <a href="/supervisores" class="btn btn-primary mb-2">Supervisores</a>
        </div>
        <div>
            <a href="/alunos" class="btn btn-primary mb-2">Alunos</a>
        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/home/index.blade.php ENDPATH**/ ?>